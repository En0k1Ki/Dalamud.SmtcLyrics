using System;

using Dalamud.Configuration;

namespace Dalamud.SmtcLyrics;

[Serializable]
public class Configuration : IPluginConfiguration
{
    public int Version { get; set; } = 1;

    public bool Enabled { get; set; } = true;

    /// <summary>DTR 文本前缀。</summary>
    public string Prefix { get; set; } = "♪ ";

    /// <summary>从网易云歌词接口拉取歌词（按曲名+歌手匹配）。</summary>
    public bool UseNetEaseLyrics { get; set; } = true;

    /// <summary>本地 .lrc 歌词文件夹（兼容 GetLrc 等工具的导出目录），优先于网易云。</summary>
    public string LyricsFolder { get; set; } = string.Empty;

    /// <summary>DTR 显示文本最大长度（超出截断加省略号，0=不截断）。</summary>
    public int MaxLineLength { get; set; } = 60;

    /// <summary>DTR 条目最小宽度（像素，0=自动）。歌词较长时调大。</summary>
    public int EntryWidth { get; set; } = 320;

    /// <summary>歌词时间偏移（毫秒，正数=歌词提前显示，负数=歌词延后）。</summary>
    public int LyricOffsetMs { get; set; } = 0;

    /// <summary>没有歌词时显示 歌手 - 歌名。</summary>
    public bool ShowTrackWhenNoLyrics { get; set; } = true;

    /// <summary>暂停时加 ⏸ 标记。</summary>
    public bool ShowPauseMark { get; set; } = true;

    /// <summary>暂停时清空歌词显示（隐藏 DTR 条目，恢复播放自动回来）。</summary>
    public bool ClearWhenPaused { get; set; } = true;

    /// <summary>只获取音乐类软件（忽略浏览器、视频播放器、游戏等）。</summary>
    public bool MusicOnly { get; set; } = true;

    /// <summary>允许的音乐软件列表（分号分隔，匹配 SMTC 来源应用 ID 的子串）。</summary>
    public string AllowedApps { get; set; } =
        "cloudmusic;qqmusic;kugou;kwmusic;spotify;foobar2000;musicbee;itunes;aimp;applemusic";

    /// <summary>没有媒体会话时隐藏 DTR 条目（关闭则显示“无媒体播放”）。</summary>
    public bool HideWhenNoSession { get; set; } = true;

    /// <summary>双语模式：有翻译歌词时在 DTR 上同时显示原文与翻译（两条相邻条目）。</summary>
    public bool Bilingual { get; set; } = true;

    /// <summary>翻译行前缀。</summary>
    public string TranslationPrefix { get; set; } = "译 ";

    /// <summary>显示模式：0=当前歌词，1=歌手-歌名，2=下一句歌词。</summary>
    public int DisplayMode { get; set; } = 0;

    public void Save() => Plugin.PluginInterface.SavePluginConfig(this);
}
