using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace Dalamud.SmtcLyrics;

/// <summary>LRC 歌词解析：支持 [mm:ss.xx] / [mm:ss:xx] 与一行多时间标签。</summary>
internal static class LrcParser
{
    private static readonly Regex TagRegex = new(@"\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]", RegexOptions.Compiled);
    private static readonly Regex MetaRegex = new(@"\[[^\]]*\]", RegexOptions.Compiled);

    private static readonly HashSet<string> MetaKeywords = new(StringComparer.Ordinal)
    {
        "作词", "作曲", "编曲", "混音", "母带", "制作", "制作人", "监制", "出品", "出品人",
        "发行", "演唱", "歌手", "和声", "录音", "配器", "词", "曲", "吉他", "贝斯", "鼓", "键盘",
        "song", "singer", "by", "作詞", "作曲者",
    };

    public static List<(double Time, string Text)> Parse(string lrc)
    {
        var result = new List<(double Time, string Text)>();

        foreach (var rawLine in lrc.Split('\n'))
        {
            var line = rawLine.TrimEnd('\r');
            var tags = TagRegex.Matches(line);
            if (tags.Count == 0)
            {
                continue;
            }

            var text = MetaRegex.Replace(line, string.Empty).Trim();
            if (string.IsNullOrEmpty(text))
            {
                continue; // [ti:]、[ar:] 等元信息行
            }

            // 过滤“作词/作曲/编曲…”等带时间戳的元信息行
            var firstToken = text.Split(new[] { '：', ':', ' ' }, 2)[0].Trim();
            if (MetaKeywords.Contains(firstToken))
            {
                continue;
            }

            foreach (Match tag in tags)
            {
                var minutes = int.Parse(tag.Groups[1].Value);
                var seconds = int.Parse(tag.Groups[2].Value);
                var time = (minutes * 60.0) + seconds;

                if (tag.Groups[3].Success)
                {
                    var fraction = tag.Groups[3].Value;
                    time += fraction.Length switch
                    {
                        1 => int.Parse(fraction) / 10.0,
                        2 => int.Parse(fraction) / 100.0,
                        _ => int.Parse(fraction) / 1000.0,
                    };
                }

                result.Add((time, text));
            }
        }

        return result.OrderBy(x => x.Time).ToList();
    }
}
