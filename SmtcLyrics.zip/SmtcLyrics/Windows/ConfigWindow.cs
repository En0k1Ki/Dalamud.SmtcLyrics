using System;
using System.Diagnostics;
using System.IO;
using System.Numerics;

using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Windowing;

namespace Dalamud.SmtcLyrics.Windows;

internal sealed class ConfigWindow : Window, IDisposable
{
    private readonly Plugin plugin;

    private string prefixInput = string.Empty;
    private string translationPrefixInput = string.Empty;
    private string lyricsFolderInput = string.Empty;
    private string allowedAppsInput = string.Empty;
    private int maxLineLengthInput;
    private bool inputSynced;

    public ConfigWindow(Plugin plugin)
        : base("SMTC 歌词设置###SmtcLyricsConfigWindow",
            ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.NoScrollbar)
    {
        this.plugin = plugin;

        Size = new Vector2(600, 560);
        SizeCondition = ImGuiCond.FirstUseEver;
    }

    public void Dispose()
    {
    }

    public override void OnOpen()
    {
        inputSynced = false;
    }

    public override void Draw()
    {
        var cfg = plugin.Configuration;

        if (!inputSynced)
        {
            prefixInput = cfg.Prefix;
            translationPrefixInput = cfg.TranslationPrefix;
            lyricsFolderInput = cfg.LyricsFolder;
            allowedAppsInput = cfg.AllowedApps;
            maxLineLengthInput = cfg.MaxLineLength;
            inputSynced = true;
        }

        ImGui.TextWrapped("监听 Windows 系统媒体控件（SMTC），在基本情报栏（DTR）实时显示当前歌曲的歌词。");
        ImGui.TextWrapped("单击歌词条 = 下一首；双击 = 播放/暂停；单击译文条 = 切换显示模式。");
        ImGui.Separator();

        CheckboxSave(cfg, "启用歌词显示", cfg.Enabled, v => cfg.Enabled = v);

        if (ImGui.InputText("显示前缀", ref prefixInput, 32))
        {
            cfg.Prefix = prefixInput;
            cfg.Save();
        }

        if (ImGui.InputInt("最大显示长度（字符，0=不截断）", ref maxLineLengthInput))
        {
            cfg.MaxLineLength = Math.Max(maxLineLengthInput, 0);
            cfg.Save();
        }

        var widthInput = cfg.EntryWidth;
        if (ImGui.InputInt("DTR 条目宽度（像素，0=自动）", ref widthInput))
        {
            cfg.EntryWidth = Math.Clamp(widthInput, 0, 1000);
            cfg.Save();
        }

        var offsetInput = cfg.LyricOffsetMs;
        if (ImGui.InputInt("歌词时间偏移（毫秒，正=提前 负=延后）", ref offsetInput))
        {
            cfg.LyricOffsetMs = Math.Clamp(offsetInput, -30000, 30000);
            cfg.Save();
        }

        ImGui.TextWrapped("歌词太长显示不全时，把条目宽度调大（原文、译文两条同时生效）。");
        ImGui.TextWrapped("官方播放器不报进度：拖动进度条后歌词会整体错位，可用偏移量手动校准；切歌后自动恢复。");

        ImGui.Separator();

        ImGui.TextUnformatted("双语显示");
        CheckboxSave(cfg, "显示翻译（外语歌自动双排：原文 + 翻译）", cfg.Bilingual, v => cfg.Bilingual = v);

        if (ImGui.InputText("翻译行前缀", ref translationPrefixInput, 32))
        {
            cfg.TranslationPrefix = translationPrefixInput;
            cfg.Save();
        }

        ImGui.TextWrapped("翻译歌词来自网易云翻译轨（tlyric）或本地带“译/translation”字样的 .lrc 文件；没有翻译时自动只显示原文。");
        ImGui.Separator();

        ImGui.TextUnformatted("显示模式");
        var mode = cfg.DisplayMode;
        if (ImGui.RadioButton("当前歌词", mode == 0))
        {
            mode = 0;
        }

        if (ImGui.RadioButton("歌手 - 歌名", mode == 1))
        {
            mode = 1;
        }

        if (ImGui.RadioButton("下一句歌词", mode == 2))
        {
            mode = 2;
        }

        if (mode != cfg.DisplayMode)
        {
            cfg.DisplayMode = mode;
            cfg.Save();
        }

        ImGui.TextWrapped("也可以单击 DTR 上的译文条循环切换这三种模式。");
        ImGui.Separator();

        ImGui.TextUnformatted("歌词来源");
        CheckboxSave(cfg, "网易云歌词接口（按曲名+歌手自动匹配）", cfg.UseNetEaseLyrics, v => cfg.UseNetEaseLyrics = v);

        if (ImGui.InputText("本地 .lrc 歌词文件夹（优先，兼容 GetLrc 导出）", ref lyricsFolderInput, 512))
        {
            cfg.LyricsFolder = lyricsFolderInput;
            cfg.Save();
        }

        if (ImGui.Button("打开本地歌词文件夹"))
        {
            TryOpenFolder(lyricsFolderInput);
        }

        CheckboxSave(cfg, "没有歌词时显示 歌手 - 歌名", cfg.ShowTrackWhenNoLyrics, v => cfg.ShowTrackWhenNoLyrics = v);
        CheckboxSave(cfg, "暂停时显示 ⏸ 标记", cfg.ShowPauseMark, v => cfg.ShowPauseMark = v);
        CheckboxSave(cfg, "暂停时清空歌词（隐藏条目）", cfg.ClearWhenPaused, v => cfg.ClearWhenPaused = v);

        ImGui.Separator();

        ImGui.TextUnformatted("来源过滤");
        CheckboxSave(cfg, "只获取音乐类软件（忽略浏览器等）", cfg.MusicOnly, v => cfg.MusicOnly = v);

        if (ImGui.InputText("允许的软件列表（分号分隔）", ref allowedAppsInput, 512))
        {
            cfg.AllowedApps = allowedAppsInput;
            cfg.Save();
        }

        ImGui.TextWrapped("按 SMTC 来源应用 ID 的子串匹配：cloudmusic=网易云，qqmusic=QQ音乐，kugou=酷狗，kwmusic=酷我，spotify、foobar2000 等。");
        CheckboxSave(cfg, "没有媒体播放时隐藏 DTR 条目", cfg.HideWhenNoSession, v => cfg.HideWhenNoSession = v);

        ImGui.Separator();
        ImGui.TextWrapped("说明：SMTC 本身不含歌词，歌词由“网易云接口”或“本地 .lrc 文件”提供；播放进度来自系统媒体控件。");
        ImGui.Separator();

        if (ImGui.Button("保存并关闭"))
        {
            cfg.Save();
            IsOpen = false;
        }
    }

    private static void CheckboxSave(Configuration cfg, string label, bool value, Action<bool> set)
    {
        var copy = value;
        if (ImGui.Checkbox(label, ref copy))
        {
            set(copy);
            cfg.Save();
        }
    }

    private static void TryOpenFolder(string folder)
    {
        try
        {
            var expanded = Environment.ExpandEnvironmentVariables(folder);
            if (string.IsNullOrWhiteSpace(expanded))
            {
                return;
            }

            Directory.CreateDirectory(expanded);
            Process.Start(new ProcessStartInfo("explorer.exe", expanded) { UseShellExecute = true });
        }
        catch (Exception)
        {
            // 打不开就不开
        }
    }
}
