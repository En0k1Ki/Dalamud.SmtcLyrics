using System;

using Dalamud.Game.Command;
using Dalamud.Game.Gui.Dtr;
using Dalamud.Interface.Windowing;
using Dalamud.IoC;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;

using Dalamud.SmtcLyrics.Windows;

namespace Dalamud.SmtcLyrics;

/// <summary>
/// 监听 Windows SMTC（系统媒体控件），把当前歌曲的歌词按播放进度
/// 实时显示在 FF14 基本情报栏（DTR）。
/// 单击歌词条目 = 下一首；双击 = 播放/暂停；单击译文条目 = 切换显示模式。
/// </summary>
public sealed class Plugin : IDalamudPlugin
{
    private const string CommandName = "/lyrics";
    private const double DoubleClickWindowMs = 350;

    [PluginService] internal static IDalamudPluginInterface PluginInterface { get; private set; } = null!;
    [PluginService] internal static ICommandManager CommandManager { get; private set; } = null!;
    [PluginService] internal static IFramework Framework { get; private set; } = null!;
    [PluginService] internal static IDtrBar DtrBar { get; private set; } = null!;
    [PluginService] internal static IPluginLog Log { get; private set; } = null!;

    public Configuration Configuration { get; init; }

    internal readonly WindowSystem WindowSystem = new("SmtcLyrics");

    private readonly ConfigWindow configWindow;
    private readonly SmtcManager smtcManager;
    private readonly LyricsProvider lyricsProvider;

    private IDtrBarEntry? dtrEntry;
    private IDtrBarEntry? dtrTransEntry;

    private string? lastTitle;
    private string? lastArtist;
    private string lastText = string.Empty;
    private string lastTransText = string.Empty;
    private string lastTooltip = string.Empty;
    private long lastTick;
    private ushort appliedWidth;
    private double lastPosition = -1;
    private bool transEntryCleared = true;
    private bool mainEntryCleared = true;

    // 单击/双击判定（DTR 点击回调在主线程触发）
    private DateTime lastClickUtc = DateTime.MinValue;
    private bool pendingSingleClick;

    public Plugin()
    {
        Configuration = PluginInterface.GetPluginConfig() as Configuration ?? new Configuration();

        // 规避 WinRT 全局 ComWrappers 冲突（必须在任何 WinRT 调用之前）
        WinRtPatch.Apply(Log);

        smtcManager = new SmtcManager(Log);
        lyricsProvider = new LyricsProvider(Configuration, Log);

        configWindow = new ConfigWindow(this);
        WindowSystem.AddWindow(configWindow);
        PluginInterface.UiBuilder.Draw += WindowSystem.Draw;
        PluginInterface.UiBuilder.OpenConfigUi += ToggleConfigUi;
        PluginInterface.UiBuilder.OpenMainUi += ToggleConfigUi;

        CommandManager.AddHandler(CommandName, new CommandInfo(OnCommand)
        {
            HelpMessage = "打开 SMTC 歌词设置",
        });

        dtrEntry = DtrBar.Get("SMTC 歌词");
        dtrEntry.OnClick = OnMainEntryClick;

        dtrTransEntry = DtrBar.Get("SMTC 歌词·译");
        dtrTransEntry.OnClick = _ => CycleDisplayMode();

        smtcManager.Start();
        Framework.Update += OnUpdate;
    }

    public void Dispose()
    {
        Framework.Update -= OnUpdate;
        CommandManager.RemoveHandler(CommandName);

        PluginInterface.UiBuilder.Draw -= WindowSystem.Draw;
        PluginInterface.UiBuilder.OpenConfigUi -= ToggleConfigUi;
        PluginInterface.UiBuilder.OpenMainUi -= ToggleConfigUi;

        WindowSystem.RemoveAllWindows();
        configWindow.Dispose();
        smtcManager.Dispose();
        lyricsProvider.Dispose();

        dtrEntry?.Remove();
        dtrEntry = null;
        dtrTransEntry?.Remove();
        dtrTransEntry = null;
    }

    public void ToggleConfigUi() => configWindow.Toggle();

    private void OnCommand(string command, string args) => configWindow.Toggle();

    // ---- 点击 = 播放控制 ----

    private void OnMainEntryClick(DtrInteractionEvent _)
    {
        var now = DateTime.UtcNow;
        if ((now - lastClickUtc).TotalMilliseconds <= DoubleClickWindowMs)
        {
            // 双击：播放/暂停
            pendingSingleClick = false;
            lastClickUtc = DateTime.MinValue;
            smtcManager.TogglePlayPause();
        }
        else
        {
            // 可能是单击：等双击窗口期结束后执行“下一首”
            lastClickUtc = now;
            pendingSingleClick = true;
        }
    }

    private void ResolvePendingClick()
    {
        if (!pendingSingleClick)
        {
            return;
        }

        if ((DateTime.UtcNow - lastClickUtc).TotalMilliseconds >= DoubleClickWindowMs)
        {
            pendingSingleClick = false;
            lastClickUtc = DateTime.MinValue;
            smtcManager.SkipNext();
        }
    }

    private void CycleDisplayMode()
    {
        Configuration.DisplayMode = (Configuration.DisplayMode + 1) % 3;
        Configuration.Save();
        lastText = string.Empty; // 强制刷新
    }

    // ---- 主循环 ----

    private void OnUpdate(IFramework framework)
    {
        // 单击判定优先处理，保证切歌响应及时
        ResolvePendingClick();

        // DTR 条目宽度（仅在配置变化时应用，避免每帧重排）
        var wantWidth = (ushort)Math.Clamp(Configuration.EntryWidth, 0, 1000);
        if (wantWidth != appliedWidth)
        {
            appliedWidth = wantWidth;
            if (dtrEntry != null)
            {
                dtrEntry.MinimumWidth = wantWidth;
            }

            if (dtrTransEntry != null)
            {
                dtrTransEntry.MinimumWidth = wantWidth;
            }
        }

        if (!Configuration.Enabled)
        {
            if (dtrEntry != null)
            {
                dtrEntry.Shown = false;
            }

            if (dtrTransEntry != null)
            {
                dtrTransEntry.Shown = false;
            }

            return;
        }

        var now = Environment.TickCount64;
        if (now - lastTick < 500)
        {
            return;
        }

        lastTick = now;

        var media = smtcManager.GetState();

        // 暂停时清空歌词显示（优先级最高：立即隐藏并清空两条条目，恢复播放自动回来）
        if (Configuration.ClearWhenPaused && !media.Playing && media.HasSession)
        {
            HideAllLyricsEntries();
            lastPosition = -1;
            return;
        }

        if (!media.HasSession || string.IsNullOrWhiteSpace(media.Title))
        {
            if (Configuration.HideWhenNoSession)
            {
                HideAllLyricsEntries();
            }
            else
            {
                ShowText("♪ 无媒体播放");
            }

            return;
        }

        // 只获取音乐类软件：来源不在白名单，或当前播放的是视频/图片，则忽略
        if (Configuration.MusicOnly &&
            (!IsAllowedMusicApp(media.SourceAppId, Configuration) || media.PlaybackType == 2 || media.PlaybackType == 3))
        {
            HideAllLyricsEntries();
            return;
        }

        if (dtrEntry != null)
        {
            dtrEntry.Shown = true;
        }

        // 播放中根据取样时间线性外推当前进度（内部时钟模式下 UpdatedUtc≈当前时刻，外推≈0）
        var position = media.PositionSeconds;
        if (media.Playing && media.UpdatedUtc != default)
        {
            position += (DateTime.UtcNow - media.UpdatedUtc).TotalSeconds;
        }

        // 进度突然跳回开头 → 新曲开始（SMTC 标题可能还没更新）：
        // 清空歌词缓存并重新加载（仅真实时间轴模式；内部时钟换歌由下方重置）
        if (!media.UsingInternalClock && media.Playing && lastPosition > 30 && position < 3)
        {
            lyricsProvider.Clear();
            lyricsProvider.OnSongChanged(media.Title, media.Artist);
            HideTranslationEntry();
        }

        if (media.Title != lastTitle || media.Artist != lastArtist)
        {
            lastTitle = media.Title;
            lastArtist = media.Artist;
            lyricsProvider.OnSongChanged(media.Title, media.Artist);
            smtcManager.ResetPlaybackClock(); // 换歌：内部播放时钟归零
            lastPosition = -1;

            // 换歌瞬间立即隐藏并清空译文条目，避免显示上一首歌的译文残留
            HideTranslationEntry();
        }

        if (media.Playing)
        {
            lastPosition = position;
        }
        else
        {
            lastPosition = -1;
        }

        // 手动时间偏移（拖动进度条导致内部时钟错位时校准）
        var lyricPosition = position + (Configuration.LyricOffsetMs / 1000.0);

        var current = lyricsProvider.GetCurrentLine(lyricPosition, out var source, out var loading);
        var next = lyricsProvider.GetNextLine(lyricPosition);
        var translated = lyricsProvider.GetTranslatedLine(lyricPosition, out var transSource);

        var pause = !media.Playing && Configuration.ShowPauseMark ? "⏸ " : string.Empty;

        string text;
        switch (Configuration.DisplayMode)
        {
            case 1:
                text = $"{pause}{Configuration.Prefix}{media.Artist} - {media.Title}";
                break;
            case 2:
                text = next != null
                    ? $"{pause}{Configuration.Prefix}{next}"
                    : current != null
                        ? $"{pause}{Configuration.Prefix}{current}"
                        : $"{pause}{Configuration.Prefix}{media.Title}";
                break;
            default:
                if (current != null)
                {
                    text = $"{pause}{Configuration.Prefix}{current}";
                }
                else if (loading)
                {
                    text = $"{pause}{Configuration.Prefix}…";
                }
                else if (Configuration.ShowTrackWhenNoLyrics)
                {
                    text = $"{pause}{Configuration.Prefix}{media.Artist} - {media.Title}";
                }
                else
                {
                    text = $"{pause}{Configuration.Prefix}♪";
                }

                break;
        }

        if (text.Length > Configuration.MaxLineLength)
        {
            text = text[..Configuration.MaxLineLength] + "…";
        }

        var tooltip = string.Join('\n',
            $"{media.Artist} - {media.Title}",
            $"歌词来源：{source ?? "无歌词（显示歌名）"}",
            $"翻译：{translated ?? "—"}",
            $"下一句：{next ?? "—"}",
            "单击：下一首　双击：播放/暂停",
            "单击译文条：切换显示模式（当前歌词 / 歌名 / 下一句）",
            "/lyrics：打开设置");

        if (text != lastText)
        {
            lastText = text;
            ShowText(text);
        }

        if (tooltip != lastTooltip && dtrEntry != null)
        {
            lastTooltip = tooltip;
            dtrEntry.Tooltip = tooltip;
        }

        UpdateTranslationEntry(translated, transSource, pause);
    }

    private static bool IsAllowedMusicApp(string? sourceAppId, Configuration cfg)
    {
        if (!cfg.MusicOnly || string.IsNullOrWhiteSpace(cfg.AllowedApps))
        {
            return true;
        }

        if (string.IsNullOrEmpty(sourceAppId))
        {
            return false;
        }

        foreach (var fragment in cfg.AllowedApps.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            if (sourceAppId.Contains(fragment, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }

        return false;
    }

    /// <summary>隐藏两条歌词条目并清空其文本节点（DTR 隐藏时文本仍留在节点里，必须一并清掉）。</summary>
    private void HideAllLyricsEntries()
    {
        if (dtrEntry != null)
        {
            if (!mainEntryCleared)
            {
                dtrEntry.Text = null;
                mainEntryCleared = true;
            }

            dtrEntry.Shown = false;
        }

        lastText = string.Empty;
        HideTranslationEntry();
    }

    /// <summary>隐藏译文条目并清空其文本节点（DTR 隐藏时文本仍留在节点里，必须一并清掉）。</summary>
    private void HideTranslationEntry()
    {
        if (dtrTransEntry == null)
        {
            return;
        }

        if (!transEntryCleared)
        {
            dtrTransEntry.Text = null;
            transEntryCleared = true;
        }

        dtrTransEntry.Shown = false;
        lastTransText = string.Empty;
    }

    private void UpdateTranslationEntry(string? translated, string? transSource, string pause)
    {
        if (dtrTransEntry == null)
        {
            return;
        }

        if (!Configuration.Bilingual || translated == null)
        {
            HideTranslationEntry();
            return;
        }

        transEntryCleared = false;

        var text = $"{pause}{Configuration.TranslationPrefix}{translated}";
        if (text.Length > Configuration.MaxLineLength)
        {
            text = text[..Configuration.MaxLineLength] + "…";
        }

        if (text != lastTransText)
        {
            lastTransText = text;
            dtrTransEntry.Text = text;
        }

        dtrTransEntry.Shown = true;
        dtrTransEntry.Tooltip = $"翻译来源：{transSource ?? "—"}\n单击：切换显示模式";
    }

    private void ShowText(string text)
    {
        if (dtrEntry == null)
        {
            return;
        }

        mainEntryCleared = false;
        dtrEntry.Shown = true;
        dtrEntry.Text = text;
    }
}
