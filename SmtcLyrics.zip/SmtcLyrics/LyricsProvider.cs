using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

using Dalamud.Plugin.Services;

namespace Dalamud.SmtcLyrics;

/// <summary>
/// 歌词来源（按优先级）：
/// 1) 本地 .lrc 文件夹（兼容 GetLrc 等工具的导出目录；带“译/translation”字样的文件作为翻译轨）；
/// 2) 网易云歌词接口（按曲名+歌手搜索匹配，同时取原文 lrc 与翻译 tlyric）。
/// 换歌时异步加载，加载期间 DTR 显示“…”。
/// </summary>
internal sealed class LyricsProvider : IDisposable
{
    private static readonly HttpClient Http = CreateHttp();

    private readonly Configuration config;
    private readonly IPluginLog log;

    private readonly object gate = new();
    private string? currentKey;
    private string? loadedKey;
    private List<(double Time, string Text)>? lines;
    private List<(double Time, string Text)>? translatedLines;
    private string? source;
    private string? translatedSource;
    private bool loading;

    public LyricsProvider(Configuration config, IPluginLog log)
    {
        this.config = config;
        this.log = log;
    }

    private static HttpClient CreateHttp()
    {
        var client = new HttpClient { Timeout = TimeSpan.FromSeconds(8) };
        client.DefaultRequestHeaders.TryAddWithoutValidation("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)");
        client.DefaultRequestHeaders.TryAddWithoutValidation("Referer", "https://music.163.com/");
        return client;
    }

    /// <summary>歌曲变化时调用：重置缓存并异步加载歌词。</summary>
    public void OnSongChanged(string? title, string? artist)
    {
        var key = MakeKey(title, artist);
        lock (gate)
        {
            if (key == currentKey)
            {
                return;
            }

            currentKey = key;
            lines = null;
            translatedLines = null;
            source = null;
            translatedSource = null;
            loading = true;
        }

        var t = title;
        var a = artist;
        _ = Task.Run(() => LoadLyrics(t, a));
    }

    /// <summary>清空当前歌曲的歌词缓存（进度跳回开头等场景使用）。</summary>
    public void Clear()
    {
        lock (gate)
        {
            currentKey = null;
            loadedKey = null;
            lines = null;
            translatedLines = null;
            source = null;
            translatedSource = null;
            loading = false;
        }
    }

    /// <summary>返回当前播放位置对应的原文歌词行；没有返回 null。</summary>
    public string? GetCurrentLine(double seconds, out string? lyricSource, out bool isLoading)
    {
        List<(double Time, string Text)>? snapshot;
        lock (gate)
        {
            if (loadedKey != currentKey)
            {
                lyricSource = null;
                isLoading = loading;
                return null;
            }

            snapshot = lines;
            lyricSource = source;
            isLoading = loading;
        }

        return FindAt(snapshot, seconds);
    }

    /// <summary>返回当前播放位置对应的翻译歌词行；没有翻译轨返回 null。</summary>
    public string? GetTranslatedLine(double seconds, out string? transSource)
    {
        List<(double Time, string Text)>? snapshot;
        lock (gate)
        {
            if (loadedKey != currentKey)
            {
                transSource = null;
                return null;
            }

            snapshot = translatedLines;
            transSource = translatedSource;
        }

        return FindAt(snapshot, seconds);
    }

    /// <summary>返回下一句原文歌词（用于 tooltip / 显示模式 2）。</summary>
    public string? GetNextLine(double seconds)
    {
        List<(double Time, string Text)>? snapshot;
        lock (gate)
        {
            if (loadedKey != currentKey)
            {
                return null;
            }

            snapshot = lines;
        }

        if (snapshot is not { Count: > 0 })
        {
            return null;
        }

        var index = FindIndex(snapshot, seconds);
        var next = index + 1;
        return next < snapshot.Count ? snapshot[next].Text : null;
    }

    private static string? FindAt(List<(double Time, string Text)>? list, double seconds)
    {
        if (list is not { Count: > 0 })
        {
            return null;
        }

        var index = FindIndex(list, seconds);
        return index >= 0 ? list[index].Text : null;
    }

    private static int FindIndex(List<(double Time, string Text)> list, double seconds)
    {
        int lo = 0, hi = list.Count - 1, answer = -1;
        while (lo <= hi)
        {
            var mid = (lo + hi) / 2;
            if (list[mid].Time <= seconds)
            {
                answer = mid;
                lo = mid + 1;
            }
            else
            {
                hi = mid - 1;
            }
        }

        return answer;
    }

    private void LoadLyrics(string? title, string? artist)
    {
        var key = MakeKey(title, artist);
        try
        {
            // 1) 本地 .lrc
            var localOriginal = TryLoadLocal(title, artist, translation: false);
            var localTranslation = TryLoadLocal(title, artist, translation: true);

            // 2) 网易云
            List<(double Time, string Text)>? neteaseOriginal = null;
            List<(double Time, string Text)>? neteaseTranslation = null;
            if (localOriginal == null || localTranslation == null)
            {
                (neteaseOriginal, neteaseTranslation) = TryLoadNetEase(title, artist);
            }

            var original = localOriginal ?? neteaseOriginal;
            var translation = localTranslation ?? neteaseTranslation;

            lock (gate)
            {
                if (currentKey != key)
                {
                    return;
                }

                loadedKey = key;
                lines = original;
                translatedLines = translation;
                source = original != null
                    ? (localOriginal != null ? "本地 LRC" : "网易云")
                    : null;
                translatedSource = translation != null
                    ? (localTranslation != null ? "本地 LRC（译）" : "网易云（译）")
                    : null;
                loading = false;
            }
        }
        catch (Exception ex)
        {
            lock (gate)
            {
                if (currentKey == key)
                {
                    loading = false;
                }
            }

            log.Debug($"SmtcLyrics: 歌词加载失败 {title} - {artist}: {ex.Message}");
        }
    }

    // ---- 本地 LRC ----

    private List<(double Time, string Text)>? TryLoadLocal(string? title, string? artist, bool translation)
    {
        if (string.IsNullOrWhiteSpace(config.LyricsFolder) || string.IsNullOrWhiteSpace(title))
        {
            return null;
        }

        var folder = Environment.ExpandEnvironmentVariables(config.LyricsFolder);
        if (!Directory.Exists(folder))
        {
            return null;
        }

        var normTitle = Normalize(title);
        var normArtist = Normalize(artist);

        string? best = null;
        var bestScore = -1;
        try
        {
            foreach (var file in Directory.EnumerateFiles(folder, "*.lrc", SearchOption.AllDirectories).Take(500))
            {
                var fileName = Normalize(Path.GetFileNameWithoutExtension(file));
                var isTranslationFile = fileName.Contains("译") || fileName.Contains("translation");
                if (translation != isTranslationFile)
                {
                    continue; // 翻译模式只挑带“译/translation”的文件，原文模式跳过它们
                }

                var score = 0;
                if (fileName == $"{normArtist} - {normTitle}" || fileName == $"{normTitle} - {normArtist}")
                {
                    score += 20;
                }

                if (!string.IsNullOrEmpty(normTitle) && fileName.Contains(normTitle))
                {
                    score += 10;
                }

                if (!string.IsNullOrEmpty(normArtist) && fileName.Contains(normArtist))
                {
                    score += 5;
                }

                if (score > bestScore)
                {
                    bestScore = score;
                    best = file;
                }
            }
        }
        catch (Exception)
        {
            return null;
        }

        if (best == null || bestScore < 10)
        {
            return null;
        }

        var parsed = LrcParser.Parse(File.ReadAllText(best, System.Text.Encoding.UTF8));
        return parsed.Count > 0 ? parsed : null;
    }

    // ---- 网易云 ----

    private (List<(double Time, string Text)>? Original, List<(double Time, string Text)>? Translation)
        TryLoadNetEase(string? title, string? artist)
    {
        if (!config.UseNetEaseLyrics || string.IsNullOrWhiteSpace(title))
        {
            return (null, null);
        }

        // 1) 搜索候选：先“歌手 歌名”，再仅“歌名”，合并去重按匹配分排序
        var candidates = new List<(long Id, int Score)>();
        foreach (var query in BuildSearchQueries(title, artist))
        {
            try
            {
                MergeCandidates(candidates, SearchSongs(query, title, artist));
            }
            catch (Exception)
            {
                // 网络抖动：跳过该查询继续
            }
        }

        if (candidates.Count == 0)
        {
            return (null, null);
        }

        candidates = candidates
            .OrderByDescending(c => c.Score)
            .ThenBy(c => c.Id)
            .Take(5)
            .ToList();

        // 2) 依次尝试候选（最多 3 个）：优先“原文+翻译”齐全的版本
        List<(double Time, string Text)>? fallbackOriginal = null;

        foreach (var (id, _) in candidates.Take(3))
        {
            var (original, translation) = FetchLyrics(id);
            if (original == null)
            {
                continue;
            }

            // 原文以汉字为主时，网易云的 tlyric 是“中→英”翻译，不需要
            if (translation != null && ContainsMostlyHan(original))
            {
                translation = null;
            }

            if (translation != null)
            {
                return (original, translation);
            }

            if (fallbackOriginal == null)
            {
                fallbackOriginal = original;
            }
        }

        return fallbackOriginal == null ? (null, null) : (fallbackOriginal, null);
    }

    private static IEnumerable<string> BuildSearchQueries(string title, string? artist)
    {
        var withArtist = $"{artist} {title}".Trim();
        if (withArtist.Length > 0)
        {
            yield return withArtist;
        }

        if (!string.IsNullOrWhiteSpace(artist) && !withArtist.Equals(title, StringComparison.OrdinalIgnoreCase))
        {
            yield return title;
        }
    }

    private List<(long Id, int Score)> SearchSongs(string query, string? title, string? artist)
    {
        var result = new List<(long Id, int Score)>();
        var form = new FormUrlEncodedContent(new Dictionary<string, string>
        {
            ["s"] = query,
            ["type"] = "1",
            ["limit"] = "10",
            ["offset"] = "0",
        });

        using var response = Http.PostAsync("https://music.163.com/api/search/get", form).GetAwaiter().GetResult();
        var json = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
        using var doc = JsonDocument.Parse(json);

        if (!doc.RootElement.TryGetProperty("result", out var resultObj) ||
            !resultObj.TryGetProperty("songs", out var songs))
        {
            return result;
        }

        foreach (var song in songs.EnumerateArray())
        {
            var name = song.TryGetProperty("name", out var n) ? n.GetString() : null;
            string? firstArtist = null;
            if (song.TryGetProperty("artists", out var artists) && artists.GetArrayLength() > 0)
            {
                firstArtist = artists[0].TryGetProperty("name", out var an) ? an.GetString() : null;
            }

            var score = MatchScore(title, artist, name, firstArtist);
            if (score > 0 && song.TryGetProperty("id", out var id))
            {
                result.Add((id.GetInt64(), score));
            }
        }

        return result;
    }

    private static void MergeCandidates(List<(long Id, int Score)> target, List<(long Id, int Score)> incoming)
    {
        foreach (var candidate in incoming)
        {
            if (!target.Any(c => c.Id == candidate.Id))
            {
                target.Add(candidate);
            }
        }
    }

    private (List<(double Time, string Text)>? Original, List<(double Time, string Text)>? Translation) FetchLyrics(long id)
    {
        try
        {
            var json = Http.GetStringAsync($"https://music.163.com/api/song/lyric?id={id}&lv=-1&kv=-1&tv=-1").GetAwaiter().GetResult();
            using var doc = JsonDocument.Parse(json);

            string? lrc = null;
            string? tlyric = null;
            if (doc.RootElement.TryGetProperty("lrc", out var lrcObj) &&
                lrcObj.TryGetProperty("lyric", out var lyricElement))
            {
                lrc = lyricElement.GetString();
            }

            if (doc.RootElement.TryGetProperty("tlyric", out var tlyricObj) &&
                tlyricObj.TryGetProperty("lyric", out var tlyricElement))
            {
                tlyric = tlyricElement.GetString();
            }

            List<(double Time, string Text)>? original = null;
            List<(double Time, string Text)>? translation = null;

            if (!string.IsNullOrWhiteSpace(lrc))
            {
                var parsed = LrcParser.Parse(lrc);
                if (parsed.Count > 0)
                {
                    original = parsed;
                }
            }

            if (!string.IsNullOrWhiteSpace(tlyric))
            {
                var parsed = LrcParser.Parse(tlyric);
                if (parsed.Count > 0)
                {
                    translation = parsed;
                }
            }

            return (original, translation);
        }
        catch (Exception)
        {
            return (null, null);
        }
    }

    /// <summary>判断歌词是否以汉字为主（不含假名——日语歌需要它的中文翻译轨）。</summary>
    private static bool ContainsMostlyHan(List<(double Time, string Text)> lines)
    {
        var han = 0;
        var total = 0;
        foreach (var (_, text) in lines)
        {
            foreach (var ch in text)
            {
                total++;
                if ((ch >= '\u3400' && ch <= '\u4dbf') ||
                    (ch >= '\u4e00' && ch <= '\u9fff') ||
                    (ch >= '\uf900' && ch <= '\ufaff'))
                {
                    han++;
                }
            }
        }

        return total > 0 && han * 2 > total;
    }

    // ---- 匹配评分 ----

    private static int MatchScore(string? title, string? artist, string? name, string? firstArtist)
    {
        var score = 0;
        var t = Normalize(title);
        var n = Normalize(name);

        if (!string.IsNullOrEmpty(t) && t == n)
        {
            score += 10;
        }
        else if (!string.IsNullOrEmpty(t) && !string.IsNullOrEmpty(n) && (n.Contains(t) || t.Contains(n)))
        {
            score += 5;
        }

        var a = Normalize(artist);
        var fa = Normalize(firstArtist);
        if (!string.IsNullOrEmpty(a) && a == fa)
        {
            score += 4;
        }
        else if (!string.IsNullOrEmpty(a) && !string.IsNullOrEmpty(fa) && (a.Contains(fa) || fa.Contains(a)))
        {
            score += 2;
        }

        return score;
    }

    private static string MakeKey(string? title, string? artist) => $"{Normalize(title)}|{Normalize(artist)}";

    private static string Normalize(string? s)
    {
        if (string.IsNullOrWhiteSpace(s))
        {
            return string.Empty;
        }

        s = s.ToLowerInvariant();
        s = Regex.Replace(s, @"[（(【\[].*?[）)】\]]", " ");
        s = Regex.Replace(s, @"feat\.?\s.*", " ");
        s = s.Replace("&", " ").Replace("、", " ").Replace("/", " ");
        s = Regex.Replace(s, @"\s+", " ").Trim();
        return s;
    }

    public void Dispose()
    {
        Http.Dispose();
    }
}
