using System;
using System.Linq;
using System.Reflection;

using Dalamud.Plugin.Services;

using Windows.Media.Control;

namespace Dalamud.SmtcLyrics;

/// <summary>
/// WinRT 投影兼容补丁：
/// WinRT.Runtime 的 ComWrappersSupport.get_ComWrappers 在首次使用时调用
/// ComWrappers.RegisterForTrackerSupport 注册【进程级全局】ComWrappers；
/// 卫月每个插件有独立 AssemblyLoadContext，各带一份 WinRT.Runtime，
/// 若其它插件先注册，本插件再注册会抛
/// InvalidOperationException("Attempt to update previously set global instance")。
/// 解决：在本插件自己的 WinRT.Runtime 副本中，预先填充其静态字段
/// _comWrappers / _instance（不注册全局），后续投影代码直接使用该实例。
/// </summary>
internal static class WinRtPatch
{
    public static void Apply(IPluginLog log)
    {
        try
        {
            // 触发 WinRT.Runtime 加载（本插件 ALC 会加载插件目录里的副本）
            _ = typeof(GlobalSystemMediaTransportControlsSessionManager);

            var asm = AppDomain.CurrentDomain.GetAssemblies()
                .FirstOrDefault(a => a.GetName().Name == "WinRT.Runtime");
            if (asm == null)
            {
                log.Debug("SmtcLyrics: 未找到 WinRT.Runtime 程序集，跳过兼容补丁");
                return;
            }

            var support = asm.GetType("WinRT.ComWrappersSupport");
            if (support == null)
            {
                return;
            }

            var comWrappersField = support.GetField("_comWrappers", BindingFlags.Static | BindingFlags.NonPublic);
            if (comWrappersField == null)
            {
                return;
            }

            if (comWrappersField.GetValue(null) != null)
            {
                return; // 已就绪（同 ALC 内之前已初始化）
            }

            var wrappersType = asm.GetType("WinRT.DefaultComWrappers");
            if (wrappersType == null)
            {
                return;
            }

            var instance = Activator.CreateInstance(wrappersType, nonPublic: true);
            comWrappersField.SetValue(null, instance);

            var instanceField = support.GetField("_instance", BindingFlags.Static | BindingFlags.NonPublic);
            instanceField?.SetValue(null, instance);

            log.Debug("SmtcLyrics: WinRT ComWrappers 兼容补丁已应用");
        }
        catch (Exception ex)
        {
            log.Debug($"SmtcLyrics: WinRT 兼容补丁失败（不影响主功能）: {ex.Message}");
        }
    }
}
