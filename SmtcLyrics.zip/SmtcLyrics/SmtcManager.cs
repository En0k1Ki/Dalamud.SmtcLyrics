using System;
using System.Threading;
using System.Threading.Tasks;

using Dalamud.Plugin.Services;

using Windows.Foundation;
using Windows.Media.Control;

namespace Dalamud.SmtcLyrics;

/// <summary>
/// SMTC 状态监听（Windows.Media.Control 投影 + 轮询模式）。
/// 后台线程每 500ms 查询当前会话的媒体属性/播放状态/时间轴，写入受锁快照；
/// 游戏主线程只读快照。播放控制（切歌/暂停）也在后台线程执行。
/// 注意：使用投影前必须先调用 WinRtPatch.Apply() 规避全局 ComWrappers 冲突。
/// </summary>
internal sealed class SmtcManager : IDisposable
{
    private readonly IPluginLog log;

    private readonly object stateLock = new();
    private readonly object sessionLock = new();

    private GlobalSystemMediaTransportControlsSessionManager? manager;
    private GlobalSystemMediaTransportControlsSession? session;
    private MediaInfo state = new();
    private DateTime lastErrorLog = DateTime.MinValue;
    private CancellationTokenSource? cts;

    // 内部播放时钟（官方客户端不更新时间轴时使用）
    private bool wasPlaying;
    private DateTime clockStartUtc = DateTime.MinValue;

    public SmtcManager(IPluginLog log)
    {
        this.log = log;
    }

    public void Start()
    {
        cts = new CancellationTokenSource();
        _ = Task.Run(() => RunLoop(cts.Token));
    }

    private async Task RunLoop(CancellationToken token)
    {
        try
        {
            manager = await GlobalSystemMediaTransportControlsSessionManager.RequestAsync();
        }
        catch (Exception ex)
        {
            LogError(ex, "SMTC 初始化失败");
        }

        while (!token.IsCancellationRequested)
        {
            try
            {
                if (manager != null)
                {
                    Poll();
                }
            }
            catch (Exception ex)
            {
                LogError(ex, "SMTC 轮询失败");
            }

            try
            {
                await Task.Delay(500, token);
            }
            catch (TaskCanceledException)
            {
                break;
            }
        }
    }

    private void Poll()
    {
        var s = manager!.GetCurrentSession();
        lock (sessionLock)
        {
            session = s;
        }

        if (s == null)
        {
            SetNoSession();
            return;
        }

        var props = s.TryGetMediaPropertiesAsync().GetAwaiter().GetResult();
        if (props == null)
        {
            SetNoSession();
            return;
        }

        var playback = s.GetPlaybackInfo();
        var timeline = s.GetTimelineProperties();
        var playing = playback.PlaybackStatus == GlobalSystemMediaTransportControlsSessionPlaybackStatus.Playing;

        // 官方网易云/QQ音乐等客户端不更新时间轴（LastUpdatedTime 为默认值）
        var timelineUpdated = timeline.LastUpdatedTime.Year > 2000;

        lock (stateLock)
        {
            if (playing && !wasPlaying)
            {
                // 开始播放：重置内部时钟
                clockStartUtc = DateTime.UtcNow;
            }

            wasPlaying = playing;

            double position;
            DateTime updatedUtc;
            if (timelineUpdated)
            {
                // 有真实时间轴：直接用，Plugin 侧按取样时间外推
                position = timeline.Position.TotalSeconds;
                updatedUtc = timeline.LastUpdatedTime.UtcDateTime;
            }
            else if (playing)
            {
                // 无时间轴：用内部播放时钟推算
                if (clockStartUtc == DateTime.MinValue)
                {
                    clockStartUtc = DateTime.UtcNow;
                }

                position = (DateTime.UtcNow - clockStartUtc).TotalSeconds;
                updatedUtc = DateTime.UtcNow;
            }
            else
            {
                position = 0;
                updatedUtc = DateTime.UtcNow;
            }

            state = new MediaInfo
            {
                Title = props.Title,
                Artist = props.Artist,
                Playing = playing,
                HasSession = true,
                SourceAppId = s.SourceAppUserModelId,
                PositionSeconds = position,
                UpdatedUtc = updatedUtc,
                PlaybackType = (int)playback.PlaybackType,
                UsingInternalClock = !timelineUpdated,
            };
        }
    }

    /// <summary>换歌时重置内部播放时钟（官方客户端时间轴缺失场景）。</summary>
    public void ResetPlaybackClock()
    {
        lock (stateLock)
        {
            clockStartUtc = DateTime.UtcNow;
        }
    }

    private void SetNoSession()
    {
        lock (stateLock)
        {
            state = new MediaInfo();
        }
    }

    // ---- 播放控制（DTR 点击）----

    /// <summary>下一首。</summary>
    public void SkipNext()
        => RunControl(s => s.TrySkipNextAsync());

    /// <summary>播放/暂停切换。</summary>
    public void TogglePlayPause()
        => RunControl(s => s.TryTogglePlayPauseAsync());

    private void RunControl(Func<GlobalSystemMediaTransportControlsSession, IAsyncOperation<bool>> action)
    {
        GlobalSystemMediaTransportControlsSession? target;
        lock (sessionLock)
        {
            target = session;
        }

        if (target == null)
        {
            return;
        }

        _ = Task.Run(() =>
        {
            try
            {
                action(target).GetAwaiter().GetResult();
            }
            catch (Exception ex)
            {
                LogError(ex, "SMTC 播放控制失败");
            }
        });
    }

    public MediaInfo GetState()
    {
        lock (stateLock)
        {
            return new MediaInfo
            {
                Title = state.Title,
                Artist = state.Artist,
                Playing = state.Playing,
                HasSession = state.HasSession,
                PositionSeconds = state.PositionSeconds,
                UpdatedUtc = state.UpdatedUtc,
                SourceAppId = state.SourceAppId,
                PlaybackType = state.PlaybackType,
                UsingInternalClock = state.UsingInternalClock,
            };
        }
    }

    private void LogError(Exception ex, string message)
    {
        if ((DateTime.UtcNow - lastErrorLog).TotalSeconds < 30)
        {
            return;
        }

        lastErrorLog = DateTime.UtcNow;
        log.Error(ex, $"SmtcLyrics: {message}");
    }

    public void Dispose()
    {
        try
        {
            cts?.Cancel();
        }
        catch (Exception)
        {
            // 忽略
        }

        lock (sessionLock)
        {
            session = null;
        }
    }
}
