using System;

namespace Dalamud.SmtcLyrics;

/// <summary>SMTC 当前媒体快照。</summary>
internal sealed class MediaInfo
{
    public string? Title;
    public string? Artist;
    public bool Playing;
    public bool HasSession;
    public double PositionSeconds;
    public DateTime UpdatedUtc;
    public string? SourceAppId;

    /// <summary>媒体类型：0=未知 1=音乐 2=视频 3=图片。</summary>
    public int PlaybackType = 1;

    /// <summary>播放器不更新时间轴（官方网易云/QQ音乐），进度由插件内部时钟推算。</summary>
    public bool UsingInternalClock;
}
